# AMI GameDay — Men's League Android App

A native Android app shell with an NBA-inspired sports dashboard, daily league schedule, standings, teams, player leaders, and YouTube game streams for [AMI Athletics](https://www.amiathletics.com/amiathleticscom1/Schedule).

> **Important status:** This is an Android **source project**, not a precompiled APK. The UI and parser have been tested locally with synthetic Men’s league data. The real AMI HTML and live YouTube listings could not be accessed from the creation environment, so live integration is **best-effort** and is **not yet verified** against the current live season. Do not confuse synthetic screenshots/tests with AMI data.

## What's included

- **Men's-only league:** Looks for selected Men’s league, follows Men’s league links, avoids women’s and youth divisions, and chooses the most recent plausible selected season when available. No hardcoded name in the UI; season selection adapts to current source pages.
- **Today / any day / full season:** Date rail, per-day fixtures, time, court, scores, source status, upcoming events.
- **Standings:** Compact team rankings, wins, losses, win %, points difference where AMI exposes them. No estimated results.
- **Teams:** Team cards, logo display, records, details and game history.
- **Player leaders:** PTS, REB, AST when the source publishes a suitable table; otherwise shows a clear no-data state.
- **Team-based visuals:** Site-hosted logos where available. Logo color sampling when image CORS allows; tasteful alternate team color gradients otherwise. Navy/gold sports-brand styling, pulsing LIVE states, animated sheets, panels, cards.
- **YouTube streams:** Tries to discover public videos on [@amiathleticsny/streams](https://www.youtube.com/@amiathleticsny/streams) and match LIVE stream titles against *both* opponents. If YouTube hides listings or does not permit an exact match, user can pick a stream from the channel list or paste a YouTube watch URL. Manual links persist per game.
- **Video player:** Embedded YouTube with fullscreen landscape mode, left-side **brightness** slider, right-side **Android music volume** slider, Reload/Go Live, and Open on YouTube. Go Live reloads to the latest available live position; exact seek behavior is up to the YouTube player.
- **Offline fallback:** Last successfully harvested AMI data is cached, but stale data is not presented as live. Buttons open the official schedule or YouTube when details are not available.
- **No YouTube API key or account login required.** YouTube may throttle or withhold channel listings in WebView; there is no guaranteed API-free way to enumerate individually scheduled game videos.

## How to make the APK with GitHub — easiest if you have a computer

1. Create a **new empty GitHub repository**, e.g. `ami-gameday-android`, and do not add a starter README.
2. Extract **AMI-GameDay-GitHub-Ready.zip** to a folder. Its contents should include `source/`, `.github/workflows/build-apk.yml`, and `README.md`.
3. Using GitHub Desktop on your Mac/PC, choose **File → Add Local Repository → Choose...** and select the extracted folder. If prompted, create a repository there.
4. Click **Publish repository**. On GitHub, open **Actions → Build AMI GameDay APK → Run workflow** (or let the first push run automatically).
5. Open the completed workflow → **Artifacts → AMI-GameDay-Android-APK** and download it. Unzip the artifact; install `app-debug.apk` on your Android phone. Android may ask you to allow installation from your chosen Files app.

### Web-only / phone-friendly route (only TWO repo additions)

The deliverables also include **AMI-GameDay-Source.zip** and **build-apk.yml** separately.

1. Create an empty GitHub repository, then choose **Add file → Upload files** and upload **AMI-GameDay-Source.zip** to the repository root. Commit it.
2. On GitHub choose **Add file → Create new file**. Name the file exactly `.github/workflows/build-apk.yml` (the `/` characters create the folders).
3. Open the downloaded **build-apk.yml** in a text editor and copy its *entire contents* into that new GitHub file. Commit it.
4. Go to **Actions → Build AMI GameDay APK → Run workflow**. When it finishes, download the APK artifact as above.

**Do not** upload only the project ZIP and expect Actions to work: GitHub cannot execute a workflow that is zipped inside an attachment. The workflow must live in `.github/workflows/` as plain text.

## Development and source data

- Project: `source/`
- Main Android activity: `source/app/src/main/java/com/ami/gameday/MainActivity.java`
- Screens and theme: `source/app/src/main/assets/index.html`, `styles.css`, `app.js`
- Real-source parser: `source/app/src/main/assets/harvest.js` and `data.js`
- YouTube video listing parser: `source/app/src/main/assets/youtube-harvest.js`
- Build recipe: `.github/workflows/build-apk.yml`
- Parser tests: `node tests/data.test.js`
- Optional browser UI tests: `python tests/ui_smoke.py` (requires Playwright/Chromium)

The Android app loads the public AMI site in an invisible WebView and reads *rendered*, publicly displayed schedules/standings into a separate native-feeling interface. It selects a Men’s league option when a suitable `<select>` is available and follows matching website navigation links. **AMI doesn't provide a documented API in this project**, so new HTML/JavaScript layouts or login-gated data may break extraction. If the new APK shows empty schedules, inspect real AMI markup and adjust `harvest.js` and `data.js` to its actual selectors. Never invent scoreboard values.

On Android, `<iframe>` playback requires YouTube to allow third-party embedding. A creator-restricted stream or one with YouTube sign-in/age restrictions must be opened directly on YouTube using the built-in external button. The app does not remove YouTube's own controls, advertising, or rights restrictions.

## Notes

- Android package: `com.ami.gameday`
- Minimum Android version: 8.0 (API 26)
- Compile/target API: 35
- Java 17 / Android Gradle Plugin 8.7.3 / Gradle 8.10.2
- Debug APK is sideloadable and is **not** a production Play Store signed release.
- Internet connection is required for live updates and YouTube viewing.
- App is an unofficial fan-made client; AMI Athletics and YouTube content and logos belong to their respective owners.
