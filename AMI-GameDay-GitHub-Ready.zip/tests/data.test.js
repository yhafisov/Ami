const assert=require('node:assert/strict');
const D=require('../source/app/src/main/assets/data.js');
const c=(text,img='')=>({text,img:img?{src:img,alt:text}:null,url:''});
const page={
 title:'AMI Athletics | Men’s Winter League 26-27',url:'https://www.amiathletics.com/amiathleticscom1/Schedule',
 headings:['Men’s Winter League 26-27'],links:[],selects:[{label:'League',options:[{text:'Men’s Winter League 26-27',selected:true,value:'w2627'},{text:'Women League',selected:false,value:'womens'}]}],
 tables:[
  {context:'Men’s Winter League 26-27 | Schedule',headers:['Date','Time','Away','Home','Court','Status'],rows:[
   {text:'Date Time Away Home Court Status',cells:['Date','Time','Away','Home','Court','Status'].map(x=>c(x))},
   {text:'11/16/2026 8:30 PM Rockets Eagles Court A LIVE',cells:[c('11/16/2026'),c('8:30 PM'),c('Rockets'),c('Eagles','https://www.amiathletics.com/eagles.png'),c('Court A'),c('LIVE')]},
   {text:'11/18/2026 7:00 PM Hawks Tigers Court C',cells:[c('11/18/2026'),c('7:00 PM'),c('Hawks'),c('Tigers'),c('Court C'),c('Scheduled')]}
  ]},
  {context:'Men’s Winter League 26-27 standings',headers:['#','Team','W','L','PCT','PF','PA'],rows:[
    {text:'1 Eagles 4 1 .800 315 310',cells:[c('1'),c('Eagles'),c('4'),c('1'),c('.800'),c('315'),c('310')]},
    {text:'2 Rockets 3 2 .600 310 305',cells:[c('2'),c('Rockets'),c('3'),c('2'),c('.600'),c('310'),c('305')]}
  ]},
  {context:'Women league standings',headers:['Team','W','L'],rows:[{text:'Bears 5 0',cells:[c('Bears'),c('5'),c('0')]}]}
 ],cards:[]
};
const data=D.build([page]);
assert.equal(data.league,'Men’s Winter League 26-27');
assert.equal(data.games.length,2);
assert.equal(data.games[0].away,'Rockets');
assert.equal(data.games[0].home,'Eagles');
assert.equal(data.games[0].date,'2026-11-16');
assert.equal(data.games[0].status,'LIVE');
assert.equal(data.standings.length,2);
assert.equal(data.standings[0].pct,.8);
assert.equal(data.standings[0].diff,5);
assert.equal(data.teams.length,4);
assert.equal(D.matchVideo(data.games[0],[{id:'a1b2c3d4e5f',title:'Rockets vs Eagles - AMI Athletics',live:true}]).id,'a1b2c3d4e5f');
assert.equal(D.matchVideo(data.games[0],[{id:'b1b2c3d4e5f',title:'Knicks vs Celtics',live:true}]),null);
assert.equal(D.dateParse('Mon Nov 16, 2026'),'2026-11-16');
assert.equal(D.dateParse('11/17/26'),'2026-11-17');
console.log('PASS: Men-only league, fixture extraction, standings, team records, video matching and dates');
