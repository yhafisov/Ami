"""Optional local browser smoke test, no network, no actual league fixtures."""
import asyncio
from pathlib import Path
from playwright.async_api import async_playwright

A = Path(__file__).resolve().parents[1] / 'source/app/src/main/assets'


def fixture():
    def cell(text, image=None):
        return {'text': str(text), 'img': {'src': image, 'alt': text} if image else None, 'url': ''}
    day = '11/16/2026'
    schedule = [
        {'text': f'{day} 7:30 PM Firebirds Kings Court A LIVE', 'cells': [cell(day), cell('7:30 PM'), cell('Firebirds'), cell('Kings'), cell('Court A'), cell('LIVE')]},
        {'text': f'{day} 9:00 PM Wolves Warriors Court B', 'cells': [cell(day), cell('9:00 PM'), cell('Wolves'), cell('Warriors'), cell('Court B'), cell('Scheduled')]},
        {'text': '11/18/2026 8:00 PM Bears Kings Court A', 'cells': [cell('11/18/2026'), cell('8:00 PM'), cell('Bears'), cell('Kings'), cell('Court A'), cell('Scheduled')]},
    ]
    return {'title': 'AMI Men’s Winter League 26-27', 'url': 'https://www.amiathletics.com/amiathleticscom1/Schedule',
            'headings': ['Men’s Winter League 26-27'], 'links': [],
            'selects': [{'label':'League','options':[{'text':'Men’s Winter League 26-27','selected':True,'value':'a'}]}],
            'tables':[
             {'context':'Men’s Winter League 26-27 Schedule','headers':['Date','Time','Away','Home','Court','Status'],'rows':schedule},
             {'context':'Men’s Winter League 26-27 Standings','headers':['#','Team','W','L','PCT','PF','PA'],'rows':[
                {'text':'1 Kings 5 1 0.833 390 360','cells':[cell(x) for x in ['1','Kings','5','1','0.833','390','360']]},
                {'text':'2 Firebirds 4 2 0.667 381 369','cells':[cell(x) for x in ['2','Firebirds','4','2','0.667','381','369']]},
             ]}
            ], 'cards': []}

async def main():
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        page = await browser.new_page(viewport={'width':390,'height':844}, device_scale_factor=1)
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        await page.route('https://**/*',lambda r:r.abort())
        html=(A/'index.html').read_text().replace('<link rel="stylesheet" href="styles.css"/>','').replace('<script src="data.js"></script><script src="app.js"></script>','')
        await page.set_content(html)
        await page.add_style_tag(content=(A/'styles.css').read_text())
        await page.add_script_tag(content=(A/'data.js').read_text())
        await page.add_script_tag(content=(A/'app.js').read_text())
        await page.evaluate('(f)=>{AMI.onSyncStart();AMI.receiveSourcePage(JSON.stringify(f));AMI.onSyncDone()}', fixture())
        assert await page.locator('text=Men’s Winter League 26-27').count() >= 1
        assert await page.locator('.hero-card .team-logo').count() == 2
        await page.screenshot(path='/mnt/data/ami-internal-preview.png',full_page=True)
        await page.locator('[data-action="standings"]').first.click()
        assert await page.locator('.standings-table tbody tr').count()==2
        await page.locator('[data-action="games"]').first.click()
        assert await page.locator('.game-card').count()==2
        await page.locator('[data-action="watch"]').first.click()
        assert await page.locator('text=SELECT GAME STREAM').count()==1
        await page.locator('#videoLinkInput').fill('https://youtu.be/aBcDeFgHiJ1')
        await page.locator('[data-action="pastevideo"]').click()
        assert await page.locator('#youtubeFrame').count()==1
        assert await page.locator('#brightnessSlider').count()==1
        assert await page.locator('#volumeSlider').count()==1
        await page.locator('[data-action="fullscreen"]').click()
        assert await page.locator('#playerLayer.immersive').count()==1
        await page.evaluate('AMI.goBack()')
        assert await page.locator('#youtubeFrame').count()==0
        assert not errors, errors
        print('PASS: dashboard, standings, daily schedule, stream picker, player controls, fullscreen and exit')
        await browser.close()

if __name__=='__main__':
    asyncio.run(main())
