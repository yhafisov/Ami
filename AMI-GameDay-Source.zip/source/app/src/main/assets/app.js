/* AMI GameDay user interface. All game and player numbers come from harvested AMI pages. */
(function(){
'use strict';
const SOURCE='https://www.amiathletics.com/amiathleticscom1/Schedule';
const CHANNEL='https://www.youtube.com/@amiathleticsny/streams';
const $=id=>document.getElementById(id);
const D=window.DataAdapter;
const ICONS={
 home:'<path d="m3 10 9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22v-8h6v8"/>',
 calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
 trophy:'<path d="M8 21h8M12 17v4M7 4h10v7a5 5 0 0 1-10 0V4ZM7 7H4v2a4 4 0 0 0 4 4M17 7h3v2a4 4 0 0 1-4 4"/>',
 users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
 chart:'<path d="M3 3v18h18M7 16v-5M12 16V7M17 16V4"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
 refresh:'<path d="M20 11a8 8 0 0 0-14-5L4 8M4 4v4h4M4 13a8 8 0 0 0 14 5l2-2M16 16h4v4"/>',
 right:'<path d="m9 18 6-6-6-6"/>',back:'<path d="m15 18-6-6 6-6"/>',
 play:'<path fill="currentColor" stroke="none" d="M7 4.5a1 1 0 0 1 1.5-.85l11 7.5a1 1 0 0 1 0 1.7l-11 7.5A1 1 0 0 1 7 19.5z"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.5h.01"/>',
 tv:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 22h8M12 19v3"/>',
 zap:'<path d="m13 2-9 12h7l-1 8 10-13h-7l1-7"/>',
 sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>',
 volume:'<path d="M11 5 6 9H3v6h3l5 4zM15 9a4 4 0 0 1 0 6M18 6a8 8 0 0 1 0 12"/>',
 expand:'<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M21 16v3a2 2 0 0 1-2 2h-3M3 16v3a2 2 0 0 0 2 2h3"/>',
 shrink:'<path d="M8 3v5H3M16 3v5h5M21 16h-5v5M3 16h5v5"/>',
 external:'<path d="M13 5h6v6M19 5l-9 9"/><path d="M19 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h6"/>',
 filter:'<path d="M4 7h16M7 12h10M10 17h4"/>',
 alert:'<path d="m12 2 10 19H2L12 2zM12 9v4M12 17h.01"/>',
 clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 close:'<path d="M18 6 6 18M6 6l12 12"/>',
 basketball:'<circle cx="12" cy="12" r="9"/><path d="M12 3c-6 6-6 12 0 18M12 3c6 6 6 12 0 18M3 12h18"/>',
 star:'<path d="m12 2 3.1 6.4 7.1 1-5.1 4.9 1.2 7-6.3-3.3-6.3 3.3 1.2-7L1.8 9.4l7.1-1z"/>',
 moon:'<path d="M20 15a9 9 0 0 1-11-11A9 9 0 1 0 20 15z"/>'
};
const icon=(k)=>`<span class="ico"><svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[k]||ICONS.info}</svg></span>`;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const url=s=>/^https:\/\//i.test(s||'')?String(s).replace(/["'<>]/g,''):'';
function initial(s){return String(s||'?').split(/[\s-]+/).filter(Boolean).slice(0,2).map(v=>v[0]).join('').toUpperCase().slice(0,3);}
const palette=[['#3d5bba','#1a2a52'],['#a33a61','#44203b'],['#157a8b','#17364a'],['#a15f28','#422d26'],['#4f51a8','#23284d'],['#397048','#1d3934'],['#a34b37','#482b30']];
let logoColors=(()=>{try{return JSON.parse(localStorage.getItem('ami-logo-colors'))||{}}catch{return {}}})();
function shade(s){if(logoColors[D.key(s)]){let color=logoColors[D.key(s)];return `linear-gradient(140deg,${color},#132138)`;}let h=0;for(let c of String(s))h=(h*31+c.charCodeAt(0))>>>0;let p=palette[h%palette.length];return `linear-gradient(140deg,${p[0]},${p[1]})`;}
function emblem(team,logo,size=''){return `<span class="team-logo ${size}" data-team="${esc(team)}" style="--teamShade:${shade(team)}">${url(logo)?`<img src="${esc(url(logo))}" alt="${esc(team)} logo" loading="lazy" onload="window.AMI.logoLoaded(this)" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"/><span style="display:none">${esc(initial(team))}</span>`:`<span>${esc(initial(team))}</span>`}</span>`;}
const navs=[['home','Home','home'],['games','Schedule','calendar'],['standings','Standings','trophy'],['teams','Teams','users'],['leaders','Leaders','chart']];
const emptyModel=()=>({league:"Men's League",games:[],standings:[],stats:[],teams:[],updatedAt:0});
let data=(()=>{try{return JSON.parse(localStorage.getItem('ami-cache'))||emptyModel()}catch{return emptyModel()}})();
let sourcePages=[];
let videoCache=(()=>{try{return JSON.parse(localStorage.getItem('ami-streams'))||{}}catch{return {}}})();
let streams=Array.isArray(videoCache)?videoCache:(videoCache.videos||[]);
let streamsUpdatedAt=Array.isArray(videoCache)?0:(videoCache.at||0);
let manual=(()=>{try{return JSON.parse(localStorage.getItem('ami-manual-streams'))||{}}catch{return {}}})();
let state={page:'home',team:null,selectedDate:nyDate(),allDates:false,tab:'pts',search:'',syncing:false,scanned:false,modal:null,gameId:null,player:null,immersive:false,volume:65,brightness:65,controls:true,sourceError:'',syncPage:0,syncTotal:0};
function nyDate(){let parts=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());let val=k=>parts.find(p=>p.type===k)?.value;return `${val('year')}-${val('month')}-${val('day')}`;}
function shift(d,offset){let day=new Date((d||nyDate())+'T12:00:00Z');day.setUTCDate(day.getUTCDate()+offset);return day.toISOString().slice(0,10);}
function fmtDate(d,options={month:'short',day:'numeric'}){if(!d)return 'Date TBD';try{return new Intl.DateTimeFormat('en-US',{timeZone:'UTC',...options}).format(new Date(d+'T12:00:00Z'))}catch{return d}}
function fmtDay(d){return fmtDate(d,{weekday:'short'}).toUpperCase()}
function fmtMonth(d){return fmtDate(d,{month:'long',year:'numeric'})}
function live(g){let m=findStream(g);let sourceFresh=Date.now()-data.updatedAt<12*60*1000;let youtubeFresh=Date.now()-streamsUpdatedAt<12*60*1000;return (g.status==='LIVE'&&sourceFresh)||!!(m?.live&&youtubeFresh);}
function findStream(g){if(manual[g.id])return D.matchVideo(g,streams,manual[g.id]);const fresh=Date.now()-streamsUpdatedAt<12*60*1000;return fresh?D.matchVideo(g,streams.filter(v=>v.live)):null;}
function nowTime(){return new Date().toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'});}
function openUrl(u){if(window.Native?.openLink)Native.openLink(u);else window.open(u,'_blank','noopener,noreferrer');}
function notify(msg){let el=$('toast');el.textContent=msg;el.classList.add('visible');clearTimeout(notify.timer);notify.timer=setTimeout(()=>el.classList.remove('visible'),2800)}
function getGame(id){return data.games.find(g=>g.id===id);}
function gameMatches(g){let needle=state.search.toLowerCase();return !needle||`${g.home} ${g.away} ${g.venue}`.toLowerCase().includes(needle);}
function teamMatches(t){return !state.search||t.name.toLowerCase().includes(state.search.toLowerCase())}
function statusHTML(g){if(live(g))return `<span class="status-live"><i class="live-dot"></i> LIVE</span>`;if(g.status==='FINAL')return `<span class="status-final">FINAL</span>`;if(g.status==='POSTPONED')return `<span class="status-final">POSTPONED</span>`;return `<span class="status-scheduled">${esc(g.time||'SCHEDULED')}</span>`;}
function section(title,sub='',link='',action=''){return `<div class="section-header"><div><div class="section-title">${esc(title)}</div>${sub?`<div class="section-kicker">${esc(sub)}</div>`:''}</div>${link?`<button class="link-button" data-action="${esc(action)}">${esc(link)} ${icon('right')}</button>`:''}</div>`;}
function empty(title,description,btn='Open AMI schedule',action='source'){return `<div class="empty-state"><span class="empty-icon">${icon('basketball')}</span><h3>${esc(title)}</h3><p>${esc(description)}</p>${btn?`<button class="action-secondary" data-action="${esc(action)}">${icon('external')} ${esc(btn)}</button>`:''}</div>`;}
function feedStatus(){let v=data.updatedAt?new Date(data.updatedAt).toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'}):'Not yet synced';let txt=state.syncing?`Checking AMI pages (${state.syncPage}/${state.syncTotal})`:`Last data update: ${v}`;return `<div class="feed-status">${icon(state.syncing?'refresh':'clock')} <span>${esc(txt)} · <b>${esc(data.league)}</b></span></div>`;}
function metric(k,v,cls=''){return `<div class="metric ${cls}"><strong>${esc(v)}</strong><span>${esc(k)}</span></div>`;}
function hero(g){
 if(!g)return `<div class="hero-card"><div class="hero-top"><span class="hero-label">NEXT TIPOFF</span><span class="hero-info">MEN'S BASKETBALL</span></div><div class="matchup"><div class="hero-team">${emblem('AMI','')}<strong>AMI MEN'S</strong></div><div class="hero-center"><span class="versus">VS</span><span class="minor">Season games</span></div><div class="hero-team">${emblem('League','')}<strong>LEAGUE</strong></div></div><div class="hero-footer"><button class="action-primary" data-action="source">${icon('refresh')} ${state.syncing?'SYNCING GAMES':'VIEW ORIGINAL SCHEDULE'}</button></div></div>`;
 return `<div class="hero-card"><div class="hero-top"><span class="hero-label">${live(g)?'GAME IN PROGRESS':g.status==='FINAL'?'LATEST RESULT':'NEXT TIPOFF'}</span><span class="hero-info">${esc(g.date?fmtDate(g.date,{weekday:'short',month:'short',day:'numeric'}):'Date TBD')} · ${esc(g.time||g.venue||'TBD')}</span></div><div class="matchup"><div class="hero-team">${emblem(g.away,g.awayLogo)}<strong>${esc(g.away)}</strong></div><div class="hero-center">${(g.status==='FINAL'||live(g))&&g.awayScore!=null&&g.homeScore!=null?`<span class="score">${esc(g.awayScore)}–${esc(g.homeScore)}</span>`:`<span class="versus">VS</span>`}${statusHTML(g)}</div><div class="hero-team">${emblem(g.home,g.homeLogo)}<strong>${esc(g.home)}</strong></div></div><div class="hero-footer"><button class="action-primary" data-action="${live(g)?'watch':'details'}" data-id="${esc(g.id)}">${icon(live(g)?'play':'info')}${live(g)?' WATCH NOW':' GAME DETAILS'}</button><button class="action-secondary" data-action="games">${icon('calendar')} Schedule</button></div></div>`;
}
function featuredGame(){let now=nyDate();let lives=data.games.filter(live);if(lives.length)return lives[0];return data.games.find(g=>g.date>=now&&g.status!=='FINAL')||[...data.games].reverse()[0]||null;}
function gameCard(g){let isLive=live(g),scored=(g.status==='FINAL'||isLive)&&g.awayScore!=null;
 return `<article class="game-card ${isLive?'live':''}" style="--accent:${isLive?'#ff617a':shade(g.home).match(/#[0-9a-f]{6}/i)?.[0]||'#7090cc'}"><div class="game-head"><span>${icon('calendar')} ${esc(fmtDate(g.date,{weekday:'short',month:'short',day:'numeric'}))} ${g.time?' · '+esc(g.time):''}</span>${statusHTML(g)}</div><div class="game-mid"><div class="game-teams"><div class="game-team">${emblem(g.away,g.awayLogo,'sm')}<span class="team-label">${esc(g.away)}</span></div><div class="game-team">${emblem(g.home,g.homeLogo,'sm')}<span class="team-label">${esc(g.home)}</span></div></div><div class="game-side">${scored?`<b class="game-score">${esc(g.awayScore??'–')}</b><b class="game-score">${esc(g.homeScore??'–')}</b>`:`<span class="minor">AWAY</span><span class="minor">HOME</span>`}</div></div><div class="game-meta"><span class="game-venue">${icon('basketball')} ${esc(g.venue||'Court TBD')}</span><div class="game-buttons">${isLive?`<button class="tiny-button watch" data-action="watch" data-id="${esc(g.id)}">${icon('play')} Watch</button>`:''}<button class="tiny-button" data-action="details" data-id="${esc(g.id)}">Details</button></div></div></article>`;
}
function gameList(games,limit=0){let list=limit?games.slice(0,limit):games;return `<div class="game-list two-col">${list.map(gameCard).join('')}</div>`;}
function renderHome(){let today=nyDate(),scheduled=data.games.filter(g=>g.date>=today&&g.status!=='FINAL'),soon=scheduled.slice(0,4), liveGames=data.games.filter(live);
 let intro=`<div class="top-intro"><div class="eyebrow">YOUR LEAGUE. YOUR COURT.</div><h1>Basketball, <em>all in.</em></h1><div class="subline"><span class="intro-description">Scores, schedules, standings & live games.</span><span class="season-badge"><i class="season-dot"></i>${esc(data.league)}</span></div></div>`;
 return intro+hero(featuredGame())+`<div class="metrics-grid">${metric('Live games',liveGames.length,'live')}${metric('Teams',data.teams.length)}${metric('Season games',data.games.length,'gold')}</div>`+
 (liveGames.length?section('Live right now','FROM AMI ATHLETICS','All games','games')+gameList(liveGames,3):'')+
 section('Up next','DON’T MISS TIPOFF','Full schedule','games')+(soon.length?gameList(soon):empty('No upcoming games available',state.syncing?'The latest Men’s league fixtures are loading.':(state.sourceError||'The website did not expose a Men’s league schedule that the app could read.')))+
 (data.standings.length?section('League leaders','TOP OF THE TABLE','Full standings','standings')+standingsTable(data.standings.slice(0,5)):'')+feedStatus();
}
function dates(){let today=nyDate(),start=shift(state.selectedDate,-3);let days=Array.from({length:12},(_,i)=>shift(start,i));return `<div class="date-rail" id="dateRail">${days.map(d=>`<button class="date-chip ${d===state.selectedDate?'active':''} ${data.games.some(g=>g.date===d)?'hasgame':''}" data-action="date" data-id="${d}"><small>${fmtDay(d)}</small><strong>${Number(d.slice(8))}</strong><small>${d===today?'TODAY':fmtDate(d,{month:'short'}).toUpperCase()}</small></button>`).join('')}</div>`;}
function renderGames(){let games=data.games.filter(gameMatches),visible=state.allDates?games:games.filter(g=>g.date===state.selectedDate),next=games.find(g=>g.date>state.selectedDate);return `<div class="top-intro"><div class="eyebrow">TIPOFF CENTRAL</div><h1>Game <em>schedule.</em></h1><div class="intro-description">Browse by date or see the entire season.</div></div><div class="date-controls"><h2>${state.allDates?'Season schedule':fmtMonth(state.selectedDate)}</h2><div><button class="outline-chip ${state.allDates?'active':''}" data-action="all">ALL GAMES</button> <button class="outline-chip" data-action="today">TODAY</button></div></div>${dates()}${section(state.allDates?'Every matchup':fmtDate(state.selectedDate,{weekday:'long',month:'long',day:'numeric'}),`${visible.length} GAME${visible.length===1?'':'S'}`)}${visible.length?gameList(visible):empty(state.search?'No matching games':'No games on this date',state.search?'Try another team or matchup.':'Swipe to another day or see the whole season.',next?'Go to next game':'View full schedule',next?'nextgame':'all')}${feedStatus()}`;}
function standingsTable(rows){return `<div class="table-wrap"><table class="standings-table"><thead><tr><th>#</th><th>TEAM</th><th>W</th><th>L</th><th>PCT</th><th>DIFF</th></tr></thead><tbody>${rows.map((r,i)=>`<tr data-action="team" data-id="${esc(D.key(r.team))}"><td>${i+1}</td><td><div class="row-team">${emblem(r.team,r.logo,'sm')}<span><strong>${esc(r.team)}</strong></span></div></td><td>${esc(r.w)}</td><td>${esc(r.l)}</td><td class="pct">${(r.pct*100).toFixed(1)}%</td><td>${r.diff==null?'–':(r.diff>0?'+':'')+esc(r.diff)}</td></tr>`).join('')}</tbody></table></div>`;}
function renderStandings(){let rows=data.standings.filter(r=>!state.search||r.team.toLowerCase().includes(state.search.toLowerCase()));return `<div class="top-intro"><div class="eyebrow">THE RACE FOR THE TOP</div><h1>League <em>standings.</em></h1><div class="intro-description">Men’s league ranking and win percentages.</div></div>${section('Season standings','AS PUBLISHED BY AMI')}${rows.length?standingsTable(rows):empty('Standings not available','The live website may display its standings through a layout that needs a source-specific integration. You can still see the official table directly.')}${rows.length?'<div class="table-note">PCT is win percentage. DIFF is points scored minus points allowed when supplied by AMI.</div>':''}${feedStatus()}`;}
function renderTeams(){let teams=data.teams.filter(teamMatches);return `<div class="top-intro"><div class="eyebrow">THE SQUADS</div><h1>Meet the <em>teams.</em></h1><div class="intro-description">Pick a team for its record and upcoming games.</div></div>${section('Men’s league teams',`${teams.length} TEAMS`)}${teams.length?`<div class="team-grid">${teams.map(t=>`<button class="team-tile" data-action="team" data-id="${esc(t.id)}">${emblem(t.name,t.logo)}<strong>${esc(t.name)}</strong><small>${t.record?`${t.record.w} W · ${t.record.l} L`:'VIEW TEAM'}</small></button>`).join('')}</div>`:empty('No teams loaded','Team names and logos will appear here once the current Men’s league can be read from AMI.')}${feedStatus()}`;}
function statValue(s,which){return s[which]??-1;}
function renderLeaders(){let which=state.tab,sorted=[...data.stats].filter(x=>x[which]!=null).sort((a,b)=>statValue(b,which)-statValue(a,which)).filter(s=>!state.search||`${s.name} ${s.team}`.toLowerCase().includes(state.search.toLowerCase()));return `<div class="top-intro"><div class="eyebrow">PERFORMANCE MATTERS</div><h1>Player <em>leaders.</em></h1><div class="intro-description">Compact season stats, when published by AMI.</div></div>${section('Top performers','MEN’S LEAGUE ONLY')}<div class="stat-switch">${[['pts','POINTS'],['reb','REBOUNDS'],['ast','ASSISTS']].map(([k,n])=>`<button class="outline-chip ${which===k?'active':''}" data-action="stat" data-id="${k}">${n}</button>`).join('')}</div>${sorted.length?`<div class="stats-list">${sorted.slice(0,35).map((s,i)=>`<div class="stats-row"><b class="stats-rank">${i+1}</b><div class="stats-person"><strong>${esc(s.name)}</strong><span>${esc(s.team||'Men’s League')}</span></div><div class="stats-num">${esc(s[which])}<small>${{pts:'PTS',reb:'REB',ast:'AST'}[which]}</small></div></div>`).join('')}</div>`:empty('Player stats are not exposed yet','The original site must publish individual stats for this panel to populate. No numbers are estimated.')}${feedStatus()}`;}
function renderTeamDetail(){let t=data.teams.find(x=>x.id===state.team);if(!t){state.page='teams';return renderTeams();}let games=data.games.filter(g=>D.key(g.home)===t.id||D.key(g.away)===t.id).filter(gameMatches);let recent=games.filter(g=>g.status==='FINAL'),upcoming=games.filter(g=>g.status!=='FINAL');return `<div class="back-bar"><button class="back-button" data-action="teams">${icon('back')} ALL TEAMS</button></div><div class="detail-hero">${emblem(t.name,t.logo,'xl')}<h1>${esc(t.name)}</h1><p>${esc(data.league)}</p><div class="record-strip"><div><strong>${t.record?.w??'–'}</strong><small>WINS</small></div><div><strong>${t.record?.l??'–'}</strong><small>LOSSES</small></div><div><strong>${t.record?(t.record.pct*100).toFixed(0)+'%':'–'}</strong><small>WIN RATE</small></div></div></div>${section('Upcoming games',`${upcoming.length} FIXTURES`)}${upcoming.length?gameList(upcoming):empty('No upcoming games found','Games for this team will appear when the Men’s league schedule is available.','','')}${recent.length?section('Previous games',`${recent.length} FINALS`)+gameList(recent.slice(-8).reverse()):''}${feedStatus()}`;}
function render(){
 $('brandSeason').textContent=data.league.toUpperCase();
 $('nav').innerHTML=navs.map(([id,name,ic])=>`<button class="nav-item ${state.page===id||state.page==='team'&&id==='teams'?'active':''}" data-action="${id}">${icon(ic)}<span>${name}</span></button>`).join('');
 $('refreshButton').classList.toggle('loading',state.syncing);
 $('main').innerHTML=({home:renderHome,games:renderGames,standings:renderStandings,teams:renderTeams,leaders:renderLeaders,team:renderTeamDetail}[state.page]||renderHome)();
}
function choosePage(page){state.page=page;state.team=null;state.search='';$('searchInput').value='';$('searchWrap').classList.add('hidden');window.scrollTo({top:0,behavior:'smooth'});render();}
function detailModal(g){const buttons=live(g)?`<button class="action-primary" data-action="watch" data-id="${esc(g.id)}">${icon('play')} Watch now</button>`:'';
 return `<div class="modal-mask" data-action="closemodal"><div class="modal-sheet" data-stop="true"><div class="modal-head"><strong>GAME CENTER</strong><button class="circle-button" data-action="closemodal">${icon('close')}</button></div><div class="matchup"><div class="hero-team">${emblem(g.away,g.awayLogo)}<strong>${esc(g.away)}</strong></div><div class="hero-center">${g.awayScore!=null?`<span class="score">${esc(g.awayScore)}–${esc(g.homeScore)}</span>`:`<span class="versus">VS</span>`}${statusHTML(g)}</div><div class="hero-team">${emblem(g.home,g.homeLogo)}<strong>${esc(g.home)}</strong></div></div><div class="modal-help">${icon('calendar')} ${esc(fmtDate(g.date,{weekday:'long',month:'long',day:'numeric',year:'numeric'}))} · ${esc(g.time||'Time TBD')}<br>${icon('basketball')} ${esc(g.venue||'Court not listed')}</div><div class="sheet-buttons">${buttons}<button class="action-secondary" data-action="closemodal">Close</button></div></div></div>`;}
function streamPicker(g){let matched=findStream(g),sorted=[...streams].sort((a,b)=>{let ma=D.matchVideo(g,[a]),mb=D.matchVideo(g,[b]);return (mb?.matchScore||0)-(ma?.matchScore||0)||Number(b.live)-Number(a.live)});
 let streamCards=sorted.slice(0,25).map(v=>`<button class="stream-option" data-action="pickstream" data-id="${esc(v.id)}"><img src="${esc(url(v.thumbnail)||'https://i.ytimg.com/vi/'+v.id+'/hqdefault.jpg')}" alt=""/><span><strong>${esc(v.title)}</strong><small>${v.live?'● LIVE ON YOUTUBE':v.upcoming?'UPCOMING STREAM':'Channel video'}${matched?.id===v.id?' · MATCH SUGGESTION':''}</small></span>${icon('play')}</button>`).join('');
 return `<div class="modal-mask" data-action="closemodal"><div class="modal-sheet" data-stop="true"><div class="modal-head"><strong>SELECT GAME STREAM</strong><button class="circle-button" data-action="closemodal">${icon('close')}</button></div><p class="modal-help">${esc(g.away)} vs ${esc(g.home)}. Streams are posted separately to the AMI Athletics YouTube channel. Choose the correct game if it wasn't matched automatically.</p>${streamCards?`<div class="stream-list">${streamCards}</div>`:empty('No individual streams discovered','YouTube sometimes restricts channel video listings. Open the channel and copy the game video link here.','','')}<label class="field-label" for="videoLinkInput">PASTE A YOUTUBE GAME LINK</label><div class="input-row"><input id="videoLinkInput" type="url" placeholder="https://youtube.com/watch?v=..."/><button class="action-primary" data-action="pastevideo">Play</button></div><p class="modal-help">Your selection is saved to this game on this phone. Video playback requires the creator to allow embedding.</p><div class="sheet-buttons"><button class="action-secondary" data-action="channel">${icon('external')} AMI streams</button><button class="action-secondary" data-action="refreshstreams">${icon('refresh')} Refresh</button></div></div></div>`;}
function videoId(input){let value=String(input||'').trim();if(/^[A-Za-z0-9_-]{11}$/.test(value))return value;
 try {let u=new URL(value),host=u.hostname.toLowerCase();if(!['youtube.com','www.youtube.com','m.youtube.com','youtu.be','www.youtube-nocookie.com'].includes(host))return null;let maybe=host==='youtu.be'?u.pathname.slice(1):u.searchParams.get('v')||u.pathname.match(/\/(?:live|embed|shorts)\/([\w-]{11})/)?.[1];return /^[\w-]{11}$/.test(maybe||'')?maybe:null;}catch{return null;}}
function watch(g){state.gameId=g.id;let matching=findStream(g);if(matching){play(g,matching.id,matching.title);}else{state.modal='stream';$('modalLayer').innerHTML=streamPicker(g);}}
function playerHTML(g,id,title){return `<div class="player-layer ${state.immersive?'immersive':''}" id="playerLayer"><div class="player-top"><button class="player-back" data-action="closeplayer">${icon('back')} Games</button><div class="player-heading"><strong>${esc(g.away)} vs ${esc(g.home)}</strong><small>AMI ATHLETICS · YOUTUBE LIVE</small></div><button class="circle-button" data-action="closeplayer">${icon('close')}</button></div><div class="player-frame"><iframe id="youtubeFrame" src="https://www.youtube-nocookie.com/embed/${esc(id)}?autoplay=1&playsinline=1&controls=1&rel=0&modestbranding=1&enablejsapi=1" title="${esc(title||'AMI Athletics game stream')}" allow="autoplay;encrypted-media;picture-in-picture;fullscreen" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe><div class="video-overlay"><div class="side-control left">${icon('sun')}<input aria-label="Brightness" id="brightnessSlider" class="vertical-slider" type="range" min="2" max="100" value="${state.brightness}"/><span class="slider-label" id="brightnessText">${state.brightness}%</span></div><div class="side-control right">${icon('volume')}<input aria-label="Volume" id="volumeSlider" class="vertical-slider" type="range" min="0" max="100" value="${state.volume}"/><span class="slider-label" id="volumeText">${state.volume}%</span></div></div></div><div class="player-controlbar"><div class="control-group"><button class="player-icon" title="Reload stream" data-action="reloadplayer">${icon('refresh')}</button><button class="player-icon ${state.immersive?'active':''}" title="Fullscreen" data-action="fullscreen">${icon(state.immersive?'shrink':'expand')}</button><button class="player-icon" title="Open on YouTube" data-action="videoexternal">${icon('external')}</button></div><button class="live-button" data-action="golive"><i class="live-dot"></i> GO LIVE</button></div><div class="player-details"><div class="eyebrow">NOW PLAYING</div><h2>${esc(title||`${g.away} vs ${g.home}`)}</h2><p>Brightness: slide on the left. Volume: slide on the right. <b>Go Live</b> reloads the stream to seek the current broadcast edge; its behavior depends on YouTube's live playback.</p><button class="action-secondary" data-action="channel">${icon('external')} View all AMI Athletics streams</button></div></div>`;}
function play(g,id,title){if(!videoId(id)){notify('This video link is invalid.');return;}state.modal=null;state.player={id,title:title||`${g.away} vs ${g.home}`,gameId:g.id};$('modalLayer').innerHTML=playerHTML(g,id,title);$('nav').style.display='none';
 try {state.volume=Native.getVolume();state.brightness=Native.getBrightness();$('volumeSlider').value=state.volume;$('brightnessSlider').value=state.brightness;$('volumeText').textContent=state.volume+'%';$('brightnessText').textContent=state.brightness+'%'}catch(_){}
}
function closePlayer(){state.player=null;state.immersive=false;window.Native?.immersive?.(false);$('modalLayer').innerHTML='';$('nav').style.display='flex';}
function reloadVideo(){let frame=$('youtubeFrame');if(!frame)return;let src=frame.getAttribute('src');frame.setAttribute('src',src.replace(/([?&])live_reload=\d+/,'')+`&live_reload=${Date.now()}`);notify('Reloading the latest stream position');}
function selectStream(id){let g=getGame(state.gameId);if(!g)return;manual[g.id]=id;try{localStorage.setItem('ami-manual-streams',JSON.stringify(manual))}catch(_){};let v=streams.find(v=>v.id===id);play(g,id,v?.title||'Selected AMI game stream');}
function sync(force=false){if(!window.Native?.requestSync){state.scanned=true;render();return;}if(state.syncing)return;if(!force&&Date.now()-data.updatedAt<8*60*1000)return;window.Native.requestSync();}
function restoreCache(){if(data?.updatedAt)state.scanned=true;}
window.AMI={
 logoLoaded(img){
   const host=img.closest('[data-team]');if(!host||!img.src)return;
   const name=host.dataset.team,id=D.key(name);
   if(logoColors[id]){host.style.setProperty('--teamShade',shade(name));return;}
   try {const sample=new Image();sample.crossOrigin='anonymous';sample.onload=()=>{
     try {const canvas=document.createElement('canvas');canvas.width=24;canvas.height=24;
       const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(sample,0,0,24,24);
       const pixels=ctx.getImageData(0,0,24,24).data;let r=0,g=0,b=0,w=0;
       for(let i=0;i<pixels.length;i+=16){let a=pixels[i+3]/255;if(a<.55)continue;
         let rr=pixels[i],gg=pixels[i+1],bb=pixels[i+2];let spread=Math.max(rr,gg,bb)-Math.min(rr,gg,bb);
         if(spread<25)continue;const weight=a*(1+spread/160);r+=rr*weight;g+=gg*weight;b+=bb*weight;w+=weight;}
       if(w<2)return;let col='#'+[r/w,g/w,b/w].map(n=>Math.min(210,Math.max(52,Math.round(n))).toString(16).padStart(2,'0')).join('');
       logoColors[id]=col;document.querySelectorAll('[data-team]').forEach(node=>{if(D.key(node.dataset.team)===id)node.style.setProperty('--teamShade',shade(name));});
       localStorage.setItem('ami-logo-colors',JSON.stringify(logoColors));
     }catch(_){} };sample.src=img.src;
   }catch(_){}
 },
 onSyncStart(){sourcePages=[];state.syncing=true;state.sourceError='';state.syncPage=0;state.syncTotal=6;render();},
 onSyncProgress(i,max){state.syncPage=i;state.syncTotal=max;render();},
 receiveSourcePage(raw){try{let page=JSON.parse(raw);if(sourcePages.some(p=>p.url===page.url))return;sourcePages.push(page);
    let fresh=D.build(sourcePages);if(fresh.games.length||fresh.standings.length||fresh.stats.length||fresh.teams.length){data=fresh;state.scanned=true;render();}
  }catch(e){console.warn('Could not interpret source page',e)}},
 onSyncDone(){state.scanned=true;state.syncing=false;let fresh=D.build(sourcePages);
  if(fresh.games.length||fresh.standings.length||fresh.teams.length||fresh.stats.length){data=fresh;data.updatedAt=Date.now();try{localStorage.setItem('ami-cache',JSON.stringify({...data,sourceLinks:data.sourceLinks.slice(0,200)}))}catch(_){} }
  else if(!data.updatedAt){data={...emptyModel(),league:fresh.league};}
  render();},
 sourceError(error){state.sourceError=String(error||'');notify('AMI source connection failed');},
 receiveYouTube(raw){try{let response=JSON.parse(raw);if(Array.isArray(response.videos)){streams=response.videos.filter(v=>videoId(v.id));streamsUpdatedAt=Date.now();localStorage.setItem('ami-streams',JSON.stringify({at:streamsUpdatedAt,videos:streams}));render();}}catch(e){console.warn('YouTube videos unavailable',e)}},
 refreshIfStale(){sync(false)},
 goBack(){if(state.player){closePlayer();return true}if(state.modal){state.modal=null;$('modalLayer').innerHTML='';return true}if(state.page!=='home'){choosePage('home');return true}return false}
};
function actionClick(event){let button=event.target.closest('[data-action]');if(!button)return;
 if(event.target.closest('[data-stop]')&&button.getAttribute('data-action')==='closemodal'&&button.hasAttribute('data-stop'))return;
 const action=button.dataset.action,id=button.dataset.id;
 if(navs.some(n=>n[0]===action)){choosePage(action);return;}
 switch(action){
  case 'source':openUrl(SOURCE);break;
  case 'refresh':sync(true);break;
  case 'search':$('searchWrap').classList.toggle('hidden');if(!$('searchWrap').classList.contains('hidden'))$('searchInput').focus();break;
  case 'closemodal':state.modal=null;$('modalLayer').innerHTML='';break;
  case 'all':state.allDates=!state.allDates;render();break;
  case 'today':state.allDates=false;state.selectedDate=nyDate();render();break;
  case 'date':state.selectedDate=id;state.allDates=false;render();break;
  case 'nextgame':{let g=data.games.filter(gameMatches).find(g=>g.date>state.selectedDate);if(g){state.selectedDate=g.date;state.allDates=false;render();}break;}
  case 'team':state.page='team';state.team=id;window.scrollTo(0,0);render();break;
  case 'stat':state.tab=id;render();break;
  case 'details':{let g=getGame(id);if(g){state.modal='detail';state.gameId=id;$('modalLayer').innerHTML=detailModal(g);}break;}
  case 'watch':{let g=getGame(id);if(g)watch(g);break;}
  case 'pickstream':selectStream(id);break;
  case 'pastevideo':{let raw=$('videoLinkInput')?.value,id=videoId(raw);if(!id){notify('Paste a valid YouTube video URL.');return;}selectStream(id);break;}
  case 'channel':openUrl(CHANNEL);break;
  case 'refreshstreams':window.Native?.requestYouTube?.();notify('Checking AMI YouTube streams');break;
  case 'closeplayer':closePlayer();break;
  case 'reloadplayer':reloadVideo();break;
  case 'golive':reloadVideo();break;
  case 'fullscreen':{state.immersive=!state.immersive;let el=$('playerLayer');el?.classList.toggle('immersive',state.immersive);window.Native?.immersive?.(state.immersive);let b=document.querySelector('[data-action="fullscreen"]');if(b)b.innerHTML=icon(state.immersive?'shrink':'expand');break;}
  case 'videoexternal':if(state.player)openUrl('https://www.youtube.com/watch?v='+state.player.id);break;
 }
}
document.addEventListener('click',actionClick);
document.addEventListener('input',event=>{
 if(event.target.id==='volumeSlider'){state.volume=+event.target.value;$('volumeText').textContent=state.volume+'%';window.Native?.volume?.(state.volume);}
 if(event.target.id==='brightnessSlider'){state.brightness=+event.target.value;$('brightnessText').textContent=state.brightness+'%';window.Native?.brightness?.(state.brightness);}
});
document.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=icon(el.dataset.icon)});
$('searchButton').addEventListener('click',()=>{$('searchWrap').classList.toggle('hidden');if(!$('searchWrap').classList.contains('hidden'))$('searchInput').focus()});
$('clearSearch').addEventListener('click',()=>{state.search='';$('searchInput').value='';$('searchWrap').classList.add('hidden');render()});
$('refreshButton').addEventListener('click',()=>sync(true));
$('searchInput').addEventListener('input',e=>{state.search=e.target.value.trim();render()});
window.addEventListener('keydown',e=>{if(e.key==='Escape')window.AMI.goBack()});
restoreCache();render();setTimeout(()=>sync(true),650);
})();
