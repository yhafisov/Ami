/* Source-data adapter. No fabricated game scores, standings or stream URLs. */
(function(root,factory){
  var result=factory();
  if(typeof module==='object' && module.exports)module.exports=result;
  root.DataAdapter=result;
})(typeof window!=='undefined'?window:globalThis,function(){
'use strict';
const MEN=/\bmen['’]?s\b|\bmens\b|\badult men\b/i;
const OTHER=/\bwomen(?:['’]?s)?\b|\bgirls?\b|\bboys?\b|youth|junior|coed|co-ed/i;
const cap=s=>String(s==null?'':s).replace(/\s+/g,' ').trim();
const key=s=>cap(s).toLowerCase().replace(/[^a-z0-9]/g,'');
const men=s=>MEN.test(s||'')&&!OTHER.test(s||'');
const nameClean=s=>cap(s).replace(/^\d+\s*[.)-]\s*/, '').replace(/\s*\(\d+[-–]\d+\)\s*$/,'').replace(/\s+(?:vs\.?|at)\s*$/i,'').slice(0,75);
const col=(headers,regex)=>headers.findIndex(h=>regex.test(cap(h).toLowerCase()));
const cell=(row,i)=>i<0?'':cap(row?.cells?.[i]?.text||'');
const image=(row,i)=>row?.cells?.[i]?.img?.src||'';
const n=s=> { let cleaned=String(s??'').replace(/[^0-9.-]/g,'');if(!/\d/.test(cleaned))return null;let v=Number(cleaned);return Number.isFinite(v)?v:null; };
const currentYear=()=>new Date().getFullYear();
function dateParse(s){
 if(!s)return '';
 let v=cap(s).replace(/\b(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\w*,?\s*/ig,'').replace(/\b(ET|EST|EDT)\b/ig,'');
 let m=v.match(/\b(20\d\d)[-\/.](\d\d?)[-\/.](\d\d?)\b/);
 if(m)return `${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`;
 m=v.match(/\b(\d{1,2})[\/-](\d{1,2})(?:[\/-](20\d\d|\d\d))?\b/);
 if(m){let yr=m[3]?Number(m[3]):currentYear();if(yr<100)yr+=2000;
  let month=+m[1],day=+m[2];if(month>=1&&month<=12&&day>=1&&day<=31)return `${yr}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;}
 m=v.match(/\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\.?\s+(\d{1,2})(?:,?\s+(20\d\d))?/i);
 if(m){let mo=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'].indexOf(m[1].slice(0,3).toLowerCase())+1;
  let year=m[3]?Number(m[3]):currentYear();return `${year}-${String(mo).padStart(2,'0')}-${m[2].padStart(2,'0')}`;}
 return '';
}
function timeParse(s){
 let m=cap(s).match(/\b(1[0-2]|0?[1-9])[:.]([0-5]\d)\s*(AM|PM)\b/i);
 if(m)return `${Number(m[1])}:${m[2]} ${m[3].toUpperCase()}`;
 m=cap(s).match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/);
 if(m){let h=+m[1];return `${h%12||12}:${m[2]} ${h>=12?'PM':'AM'}`;}
 return '';
}
function seasonRank(s){
 const str=cap(s);const matches=[...str.matchAll(/\b(20\d\d|\d\d)\s*[-–/]\s*(20\d\d|\d\d)\b/g)];
 if(matches.length){let y=Number(matches[matches.length-1][2]);if(y<100)y+=2000;return y*10 + (/winter/i.test(str)?4:/fall/i.test(str)?3:/summer/i.test(str)?2:1);}
 const single=str.match(/\b20(2\d|3\d)\b/);if(single)return (2000+Number(single[1]))*10;
 return 0;
}
function leagueCandidates(pages){
 let c=[];
 for(let p of pages){
  for(let x of p.headings||[])if(men(x))c.push(x);
  for(let l of p.links||[])if(men(l.text))c.push(l.text);
  for(let sel of p.selects||[])for(let opt of sel.options||[])if(men(opt.text))c.push(opt.text);
  if(men(p.title))c.push(p.title);
 }
 return [...new Set(c.map(cap))].sort((a,b)=>seasonRank(b)-seasonRank(a)||b.length-a.length);
}
function chooseLeague(pages){
 const selected=[];
 for(const p of pages)for(const s of p.selects||[])for(const o of s.options||[])if(o.selected&&men(o.text))selected.push(o.text);
 if(selected.length)return selected.sort((a,b)=>seasonRank(b)-seasonRank(a))[0];
 const candidates=leagueCandidates(pages);
 const current=currentYear();
 const plausible=candidates.filter(s=>{let yr=Math.floor(seasonRank(s)/10);return !yr||yr<=current+1;});
 return (plausible.length?plausible:candidates)[0]||"Men's League";
}
function selectedMens(p){return (p.selects||[]).some(x=>x.options?.some(o=>o.selected&&men(o.text))) || men(p.title) || men((p.url||'').replace(/%20/g,' '));}
function scoped(p,context,league){
 if(OTHER.test(context||''))return false;
 if(men(context||'')){
   let ctxRank=seasonRank(context),wanted=seasonRank(league);
   return !ctxRank||!wanted||ctxRank===wanted;
 }
 if(selectedMens(p))return true;
 // If the data is in a clearly men-only subpage, the page scope applies.
 let h=(p.headings||[]).join(' ');
 if(men(h) && !OTHER.test(h))return true;
 return false;
}
function tableKind(t){
 let h=(t.headers||[]).map(cap).join('|').toLowerCase(),context=cap(t.context+' '+t.caption).toLowerCase();
 if(/standing|ranking|division table/.test(context))return 'standings';
 if(/\b(team|club|squad)\b/.test(h) && (/\bw\b|wins?|\bl\b|losses|win %|pct|points for|point differential|\bpf\b|\bpa\b/.test(h)))return 'standings';
 if(/\b(home|away|visitor|opponent|matchup|fixture|game time|tipoff|date|start time)\b/.test(h)||/schedule|fixtures|games|matchups/.test(context))return 'schedule';
 if(/statistics|leader|player stats|per game/.test(context)||/player/.test(h) && /pts|ppg|reb|ast|points|rebounds/.test(h))return 'stats';
 return '';
}
function status(raw){
 let str=cap(raw);
 if(/\b(final|completed|finished|full time)\b/i.test(str))return 'FINAL';
 if(/\b(live|in progress|half(?:time)?|q[1-4]|[1-4](?:st|nd|rd|th) quarter|overtime|\bOT\b)\b/i.test(str))return 'LIVE';
 if(/\b(postponed|cancelled|canceled)\b/i.test(str))return 'POSTPONED';
 return 'SCHEDULED';
}
function fixtureNames(s){
 let t=cap(s).replace(/\b(final|live|postponed|scheduled)\b/ig,'').replace(/\b\d{1,2}:\d\d\s*(?:AM|PM)\b/gi,'').replace(/\b\d{1,2}[\/-]\d{1,2}(?:[\/-]\d{2,4})?\b/g,'');
 let m=t.match(/(.{2,80}?)\s+(?:vs\.?|versus|v\.?|@)\s+(.{2,85})/i);
 if(m)return [nameClean(m[1]),nameClean(m[2])];
 return ['',''];
}
function gameFromRow(row,table,p,league){
 let headers=(table.headers||[]).map(x=>cap(x).toLowerCase());
 let home=col(headers,/^(home|home team|host)$/),away=col(headers,/^(away|away team|visitor|visiting team|guests?)$/);
 let team=col(headers,/^(team|club)$/),op=col(headers,/^(opponent|vs\.?|matchup)$/);
 let date=col(headers,/\bdate\b|\bday\b/),tm=col(headers,/\btime\b|tip.?off|start/);
 let scoreHome=col(headers,/home\s*(score|pts)|^(hs|home pts)$/),scoreAway=col(headers,/away\s*(score|pts)|visitor\s*(score|pts)|^(as|away pts)$/);
 let venue=col(headers,/court|location|venue|gym/),state=col(headers,/status|result|game status/);
 let a=cell(row,away),b=cell(row,home),ai=image(row,away),bi=image(row,home);
 if(!a||!b){a=cell(row,team);b=cell(row,op);ai=image(row,team);bi=image(row,op);}
 if(!a||!b){let names=fixtureNames(row.text);a=names[0];b=names[1];}
 if(!a||!b||a===b||a.length>65||b.length>65||/^(home|away|visitor|opponent|team|club)$/i.test(a)||/^(home|away|visitor|opponent|team|club)$/i.test(b))return null;
 let dateText=cell(row,date)||table.context||row.text;
 let d=dateParse(dateText),time=timeParse(cell(row,tm)||row.text);
 let gameStatus=status(cell(row,state)||row.text);
 let hs=n(cell(row,scoreHome)),as=n(cell(row,scoreAway));
 if(gameStatus!=='FINAL'&&gameStatus!=='LIVE'){hs=null;as=null;}
 return {away:nameClean(a),home:nameClean(b),awayLogo:ai,homeLogo:bi,date:d,time:time,venue:cell(row,venue),status:gameStatus,homeScore:hs,awayScore:as,source:p.url,league:league};
}
function gamesFromCards(p,league){
 let all=[];
 for(let c of p.cards||[]){
  if(!scoped(p,c.context,league))continue;
  let ab=fixtureNames(c.text);
  if(!ab[0]||!ab[1])continue;
  all.push({away:ab[0],home:ab[1],awayLogo:'',homeLogo:'',date:dateParse(c.text+' '+c.context),time:timeParse(c.text),venue:'',status:status(c.text),homeScore:null,awayScore:null,source:p.url,league:league});
 }
 return all;
}
function standingsFromTable(t){
 let h=(t.headers||[]).map(x=>cap(x).toLowerCase());
 let tm=col(h,/team|club|squad/);if(tm<0)tm=1;
 let wins=col(h,/^w$|^wins?$/),losses=col(h,/^l$|^loss(es)?$/);
 let pct=col(h,/pct|win\s*%|percentage/),pf=col(h,/^pf$|points for|pts for|scored/),pa=col(h,/^pa$|points against|allowed/),diff=col(h,/diff|^\+\/-$|^\+-$/);
 let records=[];
 for(let row of t.rows||[]){
  let label=nameClean(cell(row,tm));
  if(!label || /^(team|club|rank|standings)$/i.test(label) || label.length>60)continue;
  let w=n(cell(row,wins)),l=n(cell(row,losses));
  if(w===null&&l===null)continue;
  let percent=n(cell(row,pct));if(percent!=null&&percent>1)percent/=100;
  if(percent===null&&w!=null&&l!=null&&w+l>0)percent=w/(w+l);
  let forPoints=n(cell(row,pf)),against=n(cell(row,pa)),difference=n(cell(row,diff));
  records.push({team:label,w:w??0,l:l??0,pct:percent??0,pf:forPoints,pa:against,diff:difference??(forPoints!=null&&against!=null?forPoints-against:null),logo:image(row,tm),rank:records.length+1});
 }
 return records;
}
function statsFromTable(t){
 const h=(t.headers||[]).map(x=>cap(x).toLowerCase());
 let player=col(h,/player|athlete|name/),team=col(h,/team|club/),pts=col(h,/^pts$|ppg|points/),reb=col(h,/reb|rpg/),ast=col(h,/ast|apg|assists?/);
 if(player<0 || (pts<0&&reb<0&&ast<0))return [];
 let out=[];
 for(let row of t.rows||[]){
  let name=cell(row,player);if(!name||/^(player|name|total)$/i.test(name))continue;
  out.push({name:name,team:cell(row,team),pts:n(cell(row,pts)),reb:n(cell(row,reb)),ast:n(cell(row,ast)),logo:image(row,player)});
 }
 return out;
}
function build(pages){
 const league=chooseLeague(pages), allGames=[], allStandings=[], allStats=[],links=[];
 let leagueHit=false;
 for(let p of pages){
  links.push(...(p.links||[]));
  for(let t of p.tables||[]){
   const kind=tableKind(t);
   if(!kind||!scoped(p,t.context,league))continue;
   leagueHit=true;
   if(kind==='standings')allStandings.push(...standingsFromTable(t));
   else if(kind==='stats')allStats.push(...statsFromTable(t));
   else if(kind==='schedule')for(let row of t.rows||[]){let g=gameFromRow(row,t,p,league);if(g)allGames.push(g);}
  }
  allGames.push(...gamesFromCards(p,league));
 }
 const gameMap=new Map();
 for(let g of allGames){
   let id=key(g.away)+':'+key(g.home)+':'+g.date;
   let prev=gameMap.get(id);
   let value={...g,id:id};
   if(!prev||((g.date?1:0)+(g.time?1:0)+(g.homeLogo?1:0)+(g.status==='LIVE'?3:0)) > ((prev.date?1:0)+(prev.time?1:0)+(prev.homeLogo?1:0)+(prev.status==='LIVE'?3:0)))gameMap.set(id,value);
 }
 const games=[...gameMap.values()].sort((a,b)=>(a.date||'9999').localeCompare(b.date||'9999')||(a.time||'').localeCompare(b.time||''));
 const standingsMap=new Map();
 for(let r of allStandings){let k=key(r.team);let prev=standingsMap.get(k);if(!prev||r.w+r.l>prev.w+prev.l)standingsMap.set(k,r);}
 const standings=[...standingsMap.values()].sort((a,b)=>a.rank-b.rank);
 const statsMap=new Map();for(let x of allStats){let id=key(x.name)+'_'+key(x.team);if(!statsMap.has(id))statsMap.set(id,x);}
 const teamMap=new Map();
 function addTeam(name,logo){if(!name)return;let k=key(name);if(!k)return;
   let t=teamMap.get(k)||{id:k,name:name,logo:'',record:null};
   if(logo&&!t.logo)t.logo=logo;
   teamMap.set(k,t);
 }
 for(let g of games){addTeam(g.home,g.homeLogo);addTeam(g.away,g.awayLogo);}
 for(let s of standings){addTeam(s.team,s.logo);let t=teamMap.get(key(s.team));if(t)t.record=s;}
 let teams=[...teamMap.values()].sort((a,b)=>a.name.localeCompare(b.name));
 for(let g of games){g.homeLogo=g.homeLogo||teamMap.get(key(g.home))?.logo||'';g.awayLogo=g.awayLogo||teamMap.get(key(g.away))?.logo||'';}
 return {league,leagueHit,games,standings,stats:[...statsMap.values()],teams,sourceLinks:links,updatedAt:Date.now()};
}
function matchVideo(game,videos,manualId){
 if(manualId){let v=videos.find(v=>v.id===manualId);return v||{id:manualId,title:'Selected game stream',live:false,url:'https://www.youtube.com/watch?v='+manualId,manual:true};}
 let tok=name=>cap(name).toLowerCase().replace(/\b(the|team|basketball|bc|fc|ny|new york)\b/g,'').replace(/[^a-z0-9 ]/g,' ').trim();
 let a=tok(game.away),b=tok(game.home);
 let rank=v=>{let title=tok(v.title);let score=0;if(a.length>=3&&title.includes(a))score+=5;if(b.length>=3&&title.includes(b))score+=5;
   if(v.live)score+=2; if(v.upcoming)score+=1; return score;};
 const result=[...videos].map(v=>({...v,matchScore:rank(v)})).sort((a,b)=>b.matchScore-a.matchScore);
 return result[0]&&result[0].matchScore>=10?result[0]:null;
}
return {build,matchVideo,dateParse,timeParse,seasonRank,chooseLeague,men,key,tableKind,standingsFromTable,gameFromRow,status};
});
