(function () {
  'use strict';
  if (!window.SiteHarvest || !document.body) return;
  function clean(x, max) {
    return String(x == null ? '' : x).replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max || 500);
  }
  function abs(x) {
    try { return new URL(x, location.href).href; } catch (_) { return ''; }
  }
  function img(el) {
    var node = el && el.querySelector('img');
    if (!node) return null;
    return { src: abs(node.currentSrc || node.getAttribute('data-src') || node.src), alt: clean(node.alt, 120) };
  }
  function context(node) {
    if (!node) return '';
    var labels=[];
    for(var n=node, depth=0; n && n!==document.body && depth<5; n=n.parentElement,depth++) {
      var p=n.previousElementSibling, hops=0;
      while(p && hops<4) {
        if (/^H[1-6]$/.test(p.tagName) || /league|division|category|season|schedule|standing|stats/i.test(p.className||'')) {
          var t=clean(p.innerText||p.textContent,150);
          if (t.length<150 && t.length>2) labels.push(t);
          break;
        }
        p=p.previousElementSibling;hops++;
      }
    }
    var h=node.closest('[data-league],[data-division],[data-season]');
    if(h)labels.push([h.getAttribute('data-league'),h.getAttribute('data-division'),h.getAttribute('data-season')].filter(Boolean).join(' '));
    return clean([...new Set(labels)].join(' | '),280);
  }
  function snapshot() {
    var links=[];
    document.querySelectorAll('a[href]').forEach(function(a) {
      if(links.length>=500) return;
      var label=clean(a.innerText || a.textContent || a.getAttribute('title') || a.getAttribute('aria-label'),180);
      var url=abs(a.getAttribute('href'));
      if(url.startsWith('https://') && label) links.push({text:label,url:url});
    });
    var selects=[];
    document.querySelectorAll('select').forEach(function(s) {
      if (selects.length>=30) return;
      var opts=[...s.options].slice(0,80).map(function(o){return {text:clean(o.text,140),value:clean(o.value,250),selected:o.selected};});
      var label=clean([s.name,s.id,s.getAttribute('aria-label'),s.closest('label')&&s.closest('label').innerText].filter(Boolean).join(' '),120);
      selects.push({label:label,options:opts});
      opts.forEach(function(o){
        if (/men.s|mens/i.test(o.text) && /^(https?:\/\/|\/)/.test(o.value)) {
          links.push({text:o.text,url:abs(o.value)});
        }
      });
    });
    var tables=[];
    document.querySelectorAll('table').forEach(function(t){
      if(tables.length>=65) return;
      var rows=[...t.querySelectorAll('tr')].filter(function(r){return r.closest('table')===t;}).slice(0,120);
      if(!rows.length)return;
      var head=[...t.querySelectorAll('thead tr th')].slice(0,25).map(function(c){return clean(c.innerText,80)});
      if(!head.length && rows[0].querySelector('th'))head=[...rows[0].children].map(function(c){return clean(c.innerText,80)});
      var normalized=rows.map(function(row){
        var cols=[...row.children].filter(function(c){return /^(TD|TH)$/.test(c.tagName)}).slice(0,35);
        return {
          cells:cols.map(function(c){
            var a=c.querySelector('a[href]');
            return {text:clean(c.innerText||c.textContent,240),img:img(c),url:a?abs(a.getAttribute('href')):''};
          }),
          text:clean(row.innerText||row.textContent,360),
          cls:clean(row.className,100)
        };
      });
      tables.push({context:context(t),headers:head,rows:normalized,caption:clean(t.caption&&t.caption.innerText,160)});
    });
    var cards=[];
    var selector='[class*="game" i],[class*="match" i],[class*="fixture" i],[class*="event" i],[data-game-id],[data-event-id],[class*="score" i]';
    try {document.querySelectorAll(selector).forEach(function(n){
      if(cards.length>=200 || n.children.length>35)return;
      var txt=clean(n.innerText||n.textContent,440);
      if(txt.length<12 || txt.length>400 || !(/\b(vs\.?|versus|at|live|final)\b/i.test(txt) || /\d{1,2}[:\/]\d{1,2}/.test(txt)))return;
      if(cards.some(function(x){return x.text===txt}))return;
      cards.push({text:txt,context:context(n),img:img(n),className:clean(n.className,120)});
    });} catch (_) {}
    var headings=[...document.querySelectorAll('h1,h2,h3,h4,[role=heading]')].slice(0,100).map(function(h){return clean(h.innerText,150)}).filter(Boolean);
    var body=clean(document.body.innerText||document.body.textContent,80000);
    return JSON.stringify({url:location.href,title:document.title,headings:headings,links:links,selects:selects,tables:tables,cards:cards,body:body,at:Date.now()});
  }
  var selectTarget=null,bestScore=-1;
  document.querySelectorAll('select').forEach(function(s){
    var label=clean([s.name,s.id,s.getAttribute('aria-label')].join(' '),120);
    var eligible=/league|season|division|competition|category/i.test(label) || [...s.options].some(function(o){return /men.s.*(?:league|\d{2}|winter|summer|fall|spring)/i.test(o.text)});
    if(!eligible)return;
    [...s.options].forEach(function(opt){
      var name=clean(opt.text,180);
      if(!/\bmen'?s\b|\bmens\b/i.test(name) || /women|girls|boys|junior|youth/i.test(name))return;
      var years=name.match(/\b(20\d\d|\d\d)(?:\s*[-\/]\s*(20\d\d|\d\d))?/);
      var yr=years?parseInt(years[2]||years[1],10):0;
      if(yr>2000)yr%=100;
      var score=yr*10 + (/winter/i.test(name)?4:0)+(/league/i.test(name)?2:0);
      if(score>bestScore){bestScore=score;selectTarget={select:s,opt:opt};}
    });
  });
  if(selectTarget && !selectTarget.opt.selected && !window.__amiSelectOnce){
    window.__amiSelectOnce=true;
    selectTarget.select.value=selectTarget.opt.value;
    selectTarget.select.dispatchEvent(new Event('input',{bubbles:true}));
    selectTarget.select.dispatchEvent(new Event('change',{bubbles:true}));
    setTimeout(function(){try{window.SiteHarvest.onHarvest(snapshot());}catch(e){}},1400);
  } else {
    try {window.SiteHarvest.onHarvest(snapshot());} catch(e){}
  }
})();
