(function(){
 'use strict';
 if(!window.YouTubeHarvest)return;
 function text(n){return String(n&&(n.innerText||n.textContent||'')||'').replace(/\s+/g,' ').trim();}
 var videos=[],seen=new Set();
 var selectors='ytd-rich-grid-media,ytd-video-renderer,ytd-grid-video-renderer,ytd-playlist-video-renderer,yt-lockup-view-model';
 document.querySelectorAll(selectors).forEach(function(item){
   var link=item.querySelector('a#video-title[href],a#video-title-link[href],a[href*="watch?v="],a[href*="/live/"]');
   if(!link)return;
   var href=link.href||'',match=href.match(/[?&]v=([A-Za-z0-9_-]{11})/)||href.match(/\/live\/([A-Za-z0-9_-]{11})/);
   if(!match || seen.has(match[1]))return;
   var title=(link.getAttribute('title')||link.getAttribute('aria-label')||text(link)||text(item.querySelector('#video-title'))).trim();
   if(!title)return;
   var badge=text(item.querySelector('ytd-badge-supported-renderer, #badges, .badge-shape-wiz__text, ytd-thumbnail-overlay-time-status-renderer'));
   var all=text(item).slice(0,500);
   var live=/\bLIVE\b|watching now|watching live/i.test(badge) || /\bLIVE NOW\b|watching now/i.test(all);
   if(/streamed|ago|premiered/i.test(badge) && !/watching now/i.test(all))live=false;
   var upcoming=/upcoming|scheduled|premieres/i.test(badge+' '+all);
   var thumb=item.querySelector('img');
   seen.add(match[1]);videos.push({id:match[1],title:title,live:live,upcoming:upcoming,badge:badge,thumbnail:thumb?(thumb.currentSrc||thumb.src):'',url:'https://www.youtube.com/watch?v='+match[1]});
 });
 var channelId=(document.querySelector('meta[itemprop="channelId"]')||{}).content||'';
 try{window.YouTubeHarvest.onHarvest(JSON.stringify({url:location.href,channelId:channelId,videos:videos.slice(0,80),at:Date.now()}));}catch(e){}
})();
