package com.ami.gameday;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.webkit.WebViewAssetLoader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final String SITE = "https://www.amiathletics.com/amiathleticscom1/Schedule";
    private static final String YOUTUBE = "https://www.youtube.com/@amiathleticsny/streams";
    private static final int MAX_SOURCE_PAGES = 6;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView app, scraper, youtube;
    private FrameLayout root, fullscreenContainer;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private AudioManager audio;
    private final ArrayList<SiteLink> queue = new ArrayList<>();
    private final HashSet<String> visited = new HashSet<>();
    private boolean syncing = false;
    private boolean youtubeLoaded = false;
    private int pageNumber = 0;
    private long pageToken = 0;
    private long lastSync = 0;
    private String harvestCode;
    private String youtubeCode;
    private final Runnable autoRefresh = new Runnable() {
        @Override public void run() {
            if (app != null) app.evaluateJavascript("window.AMI && AMI.refreshIfStale && AMI.refreshIfStale()", null);
            handler.postDelayed(this, 180000);
        }
    };

    private static class SiteLink {
        String url; int priority;
        SiteLink(String url, int priority) { this.url=url; this.priority=priority; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff081120);
        getWindow().setNavigationBarColor(0xff081120);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        harvestCode = assetText("harvest.js");
        youtubeCode = assetText("youtube-harvest.js");
        root = new FrameLayout(this);
        root.setBackgroundColor(0xff081120);
        setContentView(root);

        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        app = new WebView(this);
        configure(app);
        app.getSettings().setMediaPlaybackRequiresUserGesture(false);
        app.addJavascriptInterface(new AppBridge(), "Native");
        app.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                String url = req.getUrl().toString();
                if (!url.startsWith("https://appassets.androidplatform.net/")) {
                    if (req.isForMainFrame()) { openExternal(url); return true; }
                }
                return false;
            }
        });
        app.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback cb) { showFullscreen(view, cb); }
            @Override public void onHideCustomView() { hideFullscreen(); }
        });
        root.addView(app, new FrameLayout.LayoutParams(-1, -1));
        app.loadUrl("https://appassets.androidplatform.net/assets/index.html");

        scraper = new WebView(this);
        configure(scraper);
        scraper.addJavascriptInterface(new SiteReceiver(), "SiteHarvest");
        scraper.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (!syncing || !isAMI(url)) return;
                long token=pageToken;
                handler.postDelayed(() -> {
                    if (syncing && token == pageToken) runHarvest();
                }, 2400);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError err) {
                if (request.isForMainFrame()) handler.post(() -> {
                    send("window.AMI.sourceError('The AMI schedule could not be loaded. Check the connection or open the original schedule.');");
                    nextPage();
                });
            }
        });
        FrameLayout.LayoutParams tiny = new FrameLayout.LayoutParams(2, 2);
        scraper.setAlpha(0.01f);
        root.addView(scraper, 0, tiny);

        youtube = new WebView(this);
        configure(youtube);
        youtube.addJavascriptInterface(new YouTubeReceiver(), "YouTubeHarvest");
        youtube.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (!url.contains("youtube.com")) return;
                handler.postDelayed(() -> youtube.evaluateJavascript(youtubeCode, null), 4500);
                handler.postDelayed(() -> youtube.evaluateJavascript(youtubeCode, null), 9500);
            }
        });
        youtube.setAlpha(0.01f);
        root.addView(youtube, 0, new FrameLayout.LayoutParams(2,2));
        handler.postDelayed(autoRefresh, 180000);
    }

    private void configure(WebView view) {
        WebSettings s=view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setLoadWithOverviewMode(true);
        view.setBackgroundColor(0xff081120);
    }
    private String assetText(String name) {
        try (InputStream in=getAssets().open(name); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] b=new byte[8192]; int n;
            while((n=in.read(b))!=-1) out.write(b,0,n);
            return out.toString("UTF-8");
        } catch(Exception e) { return ""; }
    }
    private void send(String js) {
        handler.post(() -> { if (app != null) app.evaluateJavascript(js, null); });
    }
    private boolean isAMI(String url) {
        try { String h=Uri.parse(url).getHost(); return h!=null && (h.equals("amiathletics.com") || h.equals("www.amiathletics.com")); }
        catch(Exception e) { return false; }
    }
    private void startSync() {
        if(syncing) return;
        syncing=true; pageNumber=0; pageToken++;
        queue.clear(); visited.clear();
        queue.add(new SiteLink(SITE,1000));
        send("window.AMI.onSyncStart()");
        nextPage();
        if (!youtubeLoaded) refreshYouTube();
    }
    private void nextPage() {
        if (!syncing) return;
        Collections.sort(queue,(a,b)->Integer.compare(b.priority,a.priority));
        SiteLink next=null;
        while(!queue.isEmpty() && pageNumber<MAX_SOURCE_PAGES) {
            SiteLink item=queue.remove(0);
            if(visited.add(item.url)) { next=item; break; }
        }
        if(next==null || pageNumber>=MAX_SOURCE_PAGES) {
            syncing=false; lastSync=System.currentTimeMillis();
            send("window.AMI.onSyncDone()");
            return;
        }
        pageNumber++; pageToken++;
        final String url=next.url;
        send("window.AMI.onSyncProgress("+pageNumber+","+MAX_SOURCE_PAGES+")");
        scraper.loadUrl(url);
    }
    private void runHarvest() {
        if(harvestCode.isEmpty()) { nextPage(); return; }
        scraper.evaluateJavascript(harvestCode, null);
    }
    private void queueDiscovered(JSONObject obj) {
        JSONArray links=obj.optJSONArray("links");
        if(links==null) return;
        for(int i=0;i<links.length();i++) {
            JSONObject l=links.optJSONObject(i); if(l==null)continue;
            String url=l.optString("url","");
            if(!isAMI(url) || url.contains("#") || visited.contains(url) || url.length()>400)continue;
            String title=(l.optString("text","")+" "+url).toLowerCase();
            if(title.matches(".*(login|register|cart|privacy|contact|payment|signup|terms|photos|shop).*"))continue;
            int p=0;
            if(title.matches(".*(men.s|mens|men%27s|men\\+s|adult men).*")) p+=105;
            if(title.matches(".*(winter|summer|fall|spring).*")) p+=12;
            if(title.matches(".*(standings|ranking|table).*")) p+=75;
            if(title.matches(".*(statistics|stats|leaders).*")) p+=55;
            if(title.matches(".*(schedule|fixtures|games).*")) p+=50;
            if(title.matches(".*(teams|rosters).*")) p+=18;
            if(title.matches(".*(women|girls|boys|juniors|youth).*")) p-=200;
            if(p<=12)continue;
            boolean exists=false;
            for(SiteLink q:queue) if(q.url.equals(url)) { q.priority=Math.max(q.priority,p);exists=true;break; }
            if(!exists) queue.add(new SiteLink(url,p));
        }
    }
    private void refreshYouTube() {
        youtubeLoaded=true;
        youtube.loadUrl(YOUTUBE);
    }
    private void openExternal(String url) {
        try {
            Uri uri=Uri.parse(url);
            String host=uri.getHost();
            if(!"https".equals(uri.getScheme()) || host==null) return;
            if(!(isAMI(url) || host.equals("youtube.com") || host.endsWith(".youtube.com") || host.equals("youtu.be"))) return;
            startActivity(new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE));
        } catch(Exception ignored) { }
    }
    private void showFullscreen(View view, WebChromeClient.CustomViewCallback callback) {
        if(fullscreenView != null) { callback.onCustomViewHidden(); return; }
        fullscreenView=view;fullscreenCallback=callback;
        fullscreenContainer=new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(0xff000000);
        fullscreenContainer.addView(view,new FrameLayout.LayoutParams(-1,-1));
        root.addView(fullscreenContainer,new FrameLayout.LayoutParams(-1,-1));
        app.setVisibility(View.GONE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
    }
    private void hideFullscreen() {
        if(fullscreenView==null)return;
        fullscreenContainer.removeAllViews();
        root.removeView(fullscreenContainer);
        fullscreenView=null;fullscreenContainer=null;
        if(fullscreenCallback!=null)fullscreenCallback.onCustomViewHidden();
        fullscreenCallback=null;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        getWindow().getDecorView().setSystemUiVisibility(0);
        app.setVisibility(View.VISIBLE);
    }
    @Override public void onBackPressed() {
        if(fullscreenView!=null) { hideFullscreen(); return; }
        app.evaluateJavascript("window.AMI && AMI.goBack ? AMI.goBack() : false", value -> {
            if(!"true".equals(value)) MainActivity.super.onBackPressed();
        });
    }
    @Override public void onConfigurationChanged(Configuration config) { super.onConfigurationChanged(config); }
    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if(app!=null)app.destroy();
        if(scraper!=null)scraper.destroy();
        if(youtube!=null)youtube.destroy();
        super.onDestroy();
    }

    public class AppBridge {
        @JavascriptInterface public void requestSync() { handler.post(() -> startSync()); }
        @JavascriptInterface public void requestYouTube() { handler.post(() -> refreshYouTube()); }
        @JavascriptInterface public void openLink(String url) { handler.post(() -> openExternal(url)); }
        @JavascriptInterface public void volume(int value) {
            handler.post(() -> {
                int max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                int n=Math.round(Math.max(0,Math.min(100,value))*max/100f);
                audio.setStreamVolume(AudioManager.STREAM_MUSIC,n,0);
            });
        }
        @JavascriptInterface public void brightness(int value) {
            handler.post(() -> {
                WindowManager.LayoutParams p=getWindow().getAttributes();
                p.screenBrightness=Math.max(0.02f,Math.min(1f,value/100f));
                getWindow().setAttributes(p);
            });
        }
        @JavascriptInterface public void immersive(boolean on) {
            handler.post(() -> {
                setRequestedOrientation(on ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                getWindow().getDecorView().setSystemUiVisibility(on ? (5894 | 1024 | 512) : 0);
            });
        }
        @JavascriptInterface public int getVolume() {
            return Math.round(audio.getStreamVolume(AudioManager.STREAM_MUSIC)*100f/
                Math.max(1,audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)));
        }
        @JavascriptInterface public int getBrightness() {
            float b=getWindow().getAttributes().screenBrightness;
            return b<0?65:Math.round(b*100f);
        }
    }
    public class SiteReceiver {
        @JavascriptInterface public void onHarvest(String json) {
            if(json==null || json.length()>2200000)return;
            handler.post(() -> {
                if(!syncing)return;
                try {
                    JSONObject obj=new JSONObject(json);
                    String url=obj.optString("url", "");
                    if(!isAMI(url)) { nextPage();return; }
                    queueDiscovered(obj);
                    send("window.AMI.receiveSourcePage("+JSONObject.quote(json)+")");
                } catch(Exception ignored) { }
                nextPage();
            });
        }
    }
    public class YouTubeReceiver {
        @JavascriptInterface public void onHarvest(String json) {
            if(json==null || json.length()>300000)return;
            try {
                JSONObject o=new JSONObject(json);
                if(o.optJSONArray("videos")==null)return;
                send("window.AMI.receiveYouTube("+JSONObject.quote(json)+")");
            }catch(Exception ignored){}
        }
    }
}
